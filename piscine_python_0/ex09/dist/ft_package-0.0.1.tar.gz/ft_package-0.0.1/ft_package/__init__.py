# Exercise 09: My first package creation - ft_package module


def count_in_list(lst: list, item) -> int:
    """Compte le nombre d'occurrences d'un élément dans une liste."""
    return lst.count(item)
